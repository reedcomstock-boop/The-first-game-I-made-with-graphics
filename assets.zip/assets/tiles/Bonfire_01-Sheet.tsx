<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="Bonfire_01-Sheet" tilewidth="16" tileheight="16" tilecount="16" columns="8">
 <image source="../Props/Bonfire_01-Sheet.png" width="128" height="32"/>
</tileset>
